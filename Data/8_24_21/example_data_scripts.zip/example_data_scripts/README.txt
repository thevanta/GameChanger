Useful Info for this dataset

Participants were instructed to face southwest and perform a sensor calibration procedure three times prior to the experimental trial collection. The calibration procedure was: 1) line up directly centered with experiment computer; 2) forward trunk flexion about 30 degrees 3 times; 3) raise right arm 3 times; 4) raise right leg three times; 5) raise left leg three times.

CALIB -- calibration
FE -- flat even (horizontal; 0 grade)
CS -- cobble stone; unever stone brick
StrU -- up stairs
StrD -- down stairs
SlpU -- up slope
SlpD -- down slope
BnkL -- banked left
BnkR -- banked right
GR -- grass

Sample rate: 100 Hz
